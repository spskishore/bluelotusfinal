package page_factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class loginpage_pf {

	WebDriver dr;
	
	@FindBy(xpath="//div[@class='login-box']/form/input[1]")
	WebElement uname;
	
	@FindBy(xpath="//div[@class='login-box']/form/input[2]")
	WebElement pwd;
	
	@FindBy(xpath="//div[@class='login-box']/form/input[3]")
	WebElement btn;
	
	
	public loginpage_pf(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
	public void set_un(String un)
	{
		uname.sendKeys(un);
	}
	
	public void set_pwd(String pass)
	{
		pwd.sendKeys(pass);
	}
	
	public void clic_btn()
	{
		btn.click();
	}
	
	public void do_login(String u, String p)
	{
		this.set_un(u);
		this.set_pwd(p);
		this.clic_btn();
	}
	
	public String get_title1()
	{
		return dr.getTitle();
	}
}
