package testng;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class testsauce extends saucedemo{
	
	testsauce dr;
	
	@BeforeMethod
	public void bm(){
		dr=new testsauce();
	}
	
  @Test
  public void f() {
	  dr.login();
  }
}
