package testng;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

@Test
public class logintest {
	
	
	@BeforeMethod
	public void BM() {
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		
		dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]/a")).click();
		CharSequence uid = null;
		dr.findElement(By.xpath("//div[@class='form-fields']/form/div[2]/input")).sendKeys(uid); //uname
		CharSequence pwd = null;
		dr.findElement(By.xpath("//div[@class='form-fields']/form/div[3]/input")).sendKeys(pwd); //pwd
		dr.findElement(By.xpath("//div[@class='form-fields']/form/div[5]/input")).click();
		
	}
	
	
  public void t1() {
	  System.out.printf("abc@gmail.com","qwerty");
  }
  
  public void t2() {
	  System.out.printf("spskishore@gmail.com","qwerty");
  }
}
