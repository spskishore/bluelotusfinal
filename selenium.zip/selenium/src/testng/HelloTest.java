package testng;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class HelloTest {
	
	@BeforeMethod
	 public void bm() {
		  System.out.println("cts");
	  }
	
  @Test (priority=2)
  public void t1() {
	  System.out.println("hey");
  }
  
  @Test (priority=1)
  public void t2(){
	  System.out.println("how");
  }
  
  
  
  
  
}
