package testng;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class firefoxTest {
  @Test
  public void f() {
	  System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
		WebDriver dr = new FirefoxDriver();
		dr.get("http://demowebshop.tricentis.com");
  }
}
