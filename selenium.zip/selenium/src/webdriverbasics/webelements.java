/**
 * 
 */
/**
 * @author BLTuser
 *
 */
package webdriverbasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class webelements {
	
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		
		String s="spskishore@gmail.com";
		dr.findElement(By.linkText("Log in")).click();
		dr.findElement(By.id("Email")).sendKeys("spskishore@gmail.com");
		
		
		dr.findElement(By.id("Password")).sendKeys("qwerty");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/input")).click();
		//String n= dr.findElement(By.className("account")).getText();
//		if(s.compareTo(n)==0){
//			System.out.println("pass"); } 
//		else { System.out.println("fail"); }
//		System.out.println(n);
		String m=dr.findElement(By.xpath("//div[@class='validation-summary-errors']/span")).getText();
		//System.out.println(m);
		String n=dr.findElement(By.xpath("//div[@class='validation-summary-errors']/ul/li")).getText();
		//System.out.println(n);
		
		
	}
}
