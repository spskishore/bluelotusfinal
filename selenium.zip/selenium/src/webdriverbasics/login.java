package webdriverbasics;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class login {
	static String act_res;
	static String test_res;
	static String result;
	
	
	public static String read_excel(String file, String sheet, int row, int cell) {
		// TODO Auto-generated method stub
  File f=new File(file);
  String s=null;
  try {
	    FileInputStream fis = new FileInputStream(f);
	    XSSFWorkbook wb = new XSSFWorkbook(fis);
	    XSSFSheet sh = wb.getSheet(sheet);
	    XSSFRow row1 = sh.getRow(row);
	    XSSFCell cell1 = row1.getCell(cell);
	     s = cell1.getStringCellValue();
	    System.out.println(s);
	    
	  }  catch (IOException e) {
		                         // TODO Auto-generated catch block
		                         e.printStackTrace();
	                           } 
         return s;
	 }
	 
	
	public static void loginfunc(String uid, String pwd){
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		
		dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]/a")).click();
		dr.findElement(By.xpath("//div[@class='form-fields']/form/div[2]/input")).sendKeys(uid); //uname
		dr.findElement(By.xpath("//div[@class='form-fields']/form/div[3]/input")).sendKeys(pwd); //pwd
		dr.findElement(By.xpath("//div[@class='form-fields']/form/div[5]/input")).click();
		act_res=dr.findElement(By.xpath("//div[@class='header-links']/ul/li[1]/a")).getText();
	}



	public static void write_excel(String file, String secondsheet, int row, int cell, String act_res, String result){
		
		File f=new File(file);
		try{
			  FileInputStream fis = new FileInputStream(f);
			    XSSFWorkbook wb = new XSSFWorkbook(fis);
			    XSSFSheet sh = wb.getSheet(secondsheet);
			    XSSFRow row2 = sh.getRow(row);
			
     		    XSSFCell cell3=row2.createCell(3);
			    XSSFCell cell4=row2.createCell(4);
			    
			    cell3.setCellValue(act_res);
			    FileOutputStream fos = new FileOutputStream(f);
      		    wb.write(fos);
      		    
      		  cell4.setCellValue(result);
			    FileOutputStream fos1 = new FileOutputStream(f);
    		    wb.write(fos1);
			
		}  catch (IOException e) {
			
			   // TODO Auto-generated catch block
			   e.printStackTrace();
		}
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String file="C:\\softwares\\demo.xlsx";
		String sheet="Sheet2";
		int cell=0;
		for(int row=2;row<=5;row++){
		String eid = read_excel(file,sheet,row,cell);
		String pwd = read_excel(file,sheet,row,1);
		String expectedres=read_excel(file,sheet,row,2);
           
        loginfunc(eid,pwd);
        
        if((expectedres).equals(act_res)==true){
        	result="pass";
        } else {
        	result="fail";
        }
       
        
         write_excel(file,sheet,row,cell,act_res,result);
        
		}
	}


	
}
