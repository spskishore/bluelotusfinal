package webdriverbasics;

import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class exceptions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		
		dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]/a")).click();
		dr.findElement(By.xpath("//div[@class='form-fields']/form/div[2]/input")).sendKeys("spskishore@gmail.com"); //uname
		dr.findElement(By.xpath("//div[@class='form-fields']/form/div[3]/input")).sendKeys("qwerty"); //pwd
		dr.findElement(By.xpath("//div[@class='form-fields']/form/div[5]/input")).click();
		
		try{
			WebDriverWait wt = new WebDriverWait(dr,20);
			WebElement we = wt.until(ExpectedConditions.presenceOfElementLocated(By.linkText("Log in")));
			
			  try{
				
				   dr.findElement(By.linkText("Log in")).click();
				   
			     } 
			  catch(WebDriverException e)
			    {
				
				   System.out.println("An Exceptional case");
			    }
			
		  }  catch(TimeoutException e)
		          {
			
			        System.out.println("WebDriver couldn't locate the element");
			
		          }
		
		     System.out.println("WebDriver execution continues");
						
	}

}
