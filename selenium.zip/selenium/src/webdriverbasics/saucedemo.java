package webdriverbasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class saucedemo {

	private static String act_item1,act_price1,act_item2,act_price2;
	private static String exp_item1,exp_price1,exp_item2,exp_price2;
	private static String s1,s2;
	


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		
		dr.findElement(By.xpath("//form/input[1]")).sendKeys("standard_user");
		dr.findElement(By.xpath("//form/input[2]")).sendKeys("secret_sauce");
		dr.findElement(By.xpath("//form/input[3]")).click();
		
		//-----------------------------------------------------------------------------------------
		
		
		
		exp_item1=dr.findElement(By.xpath("//div[@class='inventory_list']/div[1]/div[2]/a/div")).getText();
		exp_item2=dr.findElement(By.xpath("//div[@class='inventory_list']/div[5]/div[2]/a/div")).getText();
				
		exp_price1=dr.findElement(By.xpath("//div[@class='inventory_list']/div[1]/div[3]/div")).getText();
		s1=exp_price1.replace("$","");
	//	System.out.println(s1);
				
		exp_price2=dr.findElement(By.xpath("//div[@class='inventory_list']/div[5]/div[3]/div")).getText();	
		s2=exp_price2.replace("$","");
		//System.out.println(s2);
		
		dr.findElement(By.xpath("//div[@class='inventory_list']/div[1]/div[3]/button")).click(); //add to cart 1
		dr.findElement(By.xpath("//div[@class='inventory_list']/div[5]/div[3]/button")).click(); //add to cart 2
		
		dr.findElement(By.xpath("//div[@class='shopping_cart_container']/a/span")).click(); // go to cart
		
		act_item1=dr.findElement(By.xpath("//div[@class='cart_list']/div[3]/div[2]/a/div")).getText();
		act_item2=dr.findElement(By.xpath("//div[@class='cart_list']/div[4]/div[2]/a/div")).getText();
		
		act_price1 = dr.findElement(By.xpath("//div[@class='cart_list']/div[3]/div[2]/div[2]/div")).getText();
		act_price2 = dr.findElement(By.xpath("//div[@class='cart_list']/div[4]/div[2]/div[2]/div")).getText();
		
		//System.out.println("actprice1 " +act_price1);
		
		
		//---------------------------------------------------------------
		

	
		
		if(exp_item1.compareTo(act_item1)==0) {
			
			System.out.println("product 1 verified");}
			
		  if(exp_item2.compareTo(act_item2)==0){
			
			System.out.println("product 2 verified");
			
		}  
		 if(act_price1.compareTo(s1)==0)
		{
			System.out.println("price 1 verified");
			
			} 
		 
		 if(act_price2.compareTo(s2)==0)
		{
			System.out.println("price 2 verified");	
		}
		 
		
		else {
			
			System.out.println("fail");
			
		    }
		
		}
		
	
	}


