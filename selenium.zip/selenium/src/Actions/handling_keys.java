package Actions;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class handling_keys {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		
		WebElement email=dr.findElement(By.id("Email"));
		WebElement pass=dr.findElement(By.id("Password"));
		
		Actions a = new Actions(dr);
		
		a.keyDown(email, Keys.SHIFT)
		 .sendKeys(email, "spskishore")
		 .keyUp(email, Keys.SHIFT)
		 .build()
		 .perform();
		
		
		
		
		
		
		
		
	}

}
