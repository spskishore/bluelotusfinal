package s;

import org.testng.annotations.Test;

public class NewTest1 {
  @Test
  public void f() {
	  System.out.println("hi");
  }
}
