package s;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class sewTest {
	private SoftAssert sa;
	
	
	  @Test
	  public void t3(){
		  
		  System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		  WebDriver dr = new ChromeDriver();
		  dr.get("http://demowebshop.tricentis.com");
		 
		  String t="Demo Web Shop";
		  String act_title=dr.getTitle();
		  sa = new SoftAssert();
		  sa.assertEquals(t,act_title);
		  System.out.println("title is equal or not");
		  sa.assertAll();
	  
	     }
}
