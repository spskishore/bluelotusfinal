package Assignment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class read_excel {
   
	
	 static String filename="C:\\softwares\\data.xlsx";
	 static String sheetname="Login";
	 
	 public static String[][]testdata=new String[3][5];
	 public static int rowno,colno;

		public void get_test_data(){
			
			
			   
			                try{
				                          
			                       System.out.println("in get test data row: " +rowno);
			                               File f=new File(filename);
			                               FileInputStream fis = new FileInputStream(f);
				                           XSSFWorkbook wb = new XSSFWorkbook(fis);
				                           XSSFSheet sh = wb.getSheet(sheetname);
				                           
				                  for(rowno=1;rowno<=2;rowno++){
				                	  
				                           XSSFRow r = sh.getRow(rowno);
				                           XSSFCell cell1 = r.getCell(0);
				                           testdata[rowno][0]=cell1.getStringCellValue();
				                         
				                           XSSFCell cell2 = r.getCell(1);
				                           testdata[rowno][1]=cell2.getStringCellValue();
				                        
				                           XSSFCell cell3 = r.getCell(2);
				                           testdata[rowno][2]=cell3.getStringCellValue();
				                      
				                           XSSFCell cell4 = r.getCell(3);
				                           testdata[rowno][3]=cell4.getStringCellValue();
				                       
				                           XSSFCell cell5 = r.getCell(4);
				                           testdata[rowno][4]=cell5.getStringCellValue();
				                         
			                          }
				                  }
			         catch(FileNotFoundException e)
			                { 
			    	          e.printStackTrace();
			                }
			        catch(IOException e)
			                { 
				               e.printStackTrace();
			                }
			
				
		
		}
}
