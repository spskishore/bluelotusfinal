package Assignment;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class Registration {

	public static String reg,reg_success;
	
	public String new_reg(String FN, String LN,String email,String pwd, String c_pwd) throws IOException{
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.manage().window().maximize();
		dr.get("http://demowebshop.tricentis.com");
		
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		
		dr.findElement(By.xpath("//a[@class='ico-register']")).click();
		
		WebElement radio=dr.findElement(By.xpath("//div[@class='form-fields']/div/div[1]/input"));
		radio.click();
		dr.findElement(By.xpath("//input[@name='FirstName']")).sendKeys(FN);
		dr.findElement(By.xpath("//input[@name='LastName']")).sendKeys(LN);
		dr.findElement(By.xpath("//div[@class='form-fields']/div[4]/input")).sendKeys(email);
		dr.findElement(By.xpath("//div[@class='page-body']/div[3]/div[2]/div[1]/input")).sendKeys(pwd);
		dr.findElement(By.xpath("//div[@class='page-body']/div[3]/div[2]/div[2]/input")).sendKeys(c_pwd);
		
reg=dr.findElement(By.xpath("//div[@class='header-links']/ul/li[1]/a")).getText();

		dr.findElement(By.xpath("//div[@class='page-body']/div[4]/input")).click();
		
		//reg_success=dr.findElement(By.xpath("//div[@class='page-body']/div[1]")).getText(); //your registration completed
		//dr.findElement(By.xpath("//div[@class='validation-summary-errors']/ul/li")).getText();//The specified email already exists
reg_success=dr.findElement(By.xpath("//div[@class='header-links']/ul/li[1]/a")).getText();
		//dr.findElement(By.xpath("//div[@class='page-body']/div[2]/input")).click(); //continue
		dr.close();
		
		if(reg.compareTo(reg_success)==0) {
			File f1=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
			File f2=new File("C:\\softwares\\screeshotsuccess.png");
			FileUtils.copyFile(f1, f2);}
			else {					
			File f3=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
			File f4=new File("C:\\softwares\\screeshotfail.png");
			FileUtils.copyFile(f3, f4);}
		
		return reg_success;
		
		
	}
}
