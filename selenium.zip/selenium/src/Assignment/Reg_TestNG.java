package Assignment;

import java.io.IOException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Reg_TestNG extends Registration{
	
	read_excel r; 

	@BeforeClass
	 public void getdata(){
		
		               r=new read_excel();
		               r.get_test_data();
	    }
	
   @Test(dataProvider="regist")
    public void f(String FN, String LN,String email,String pwd, String c_pwd) throws IOException {
	       
	   new_reg(FN, LN, email, pwd, c_pwd);
  
        }
  
  
  
  @DataProvider(name="regist")
    public String[][] prov_data(){
		  
                                  return r.testdata;
       
	                        }
}
