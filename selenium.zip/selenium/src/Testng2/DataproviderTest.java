package Testng2;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataproviderTest {
  @Test(dataProvider="login_data")
  public void login(String eid, String pwd) {
	  System.out.println("email id: " +eid + " Pwd: " +pwd);
  }
  
  @DataProvider(name="login_data")
  public String[][] providedata(){
	  String[][] data={
			  {"e1","p1"},
			  {"e2","p2"}
	  };
	return data;
	  
  }
}
