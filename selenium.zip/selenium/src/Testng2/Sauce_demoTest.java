package Testng2;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Sauce_demoTest {
	
	WebDriver dr;
	
	private String expitem,exp_price;
	private String actitem,act_price;
	
	addproductsauce obj=new addproductsauce();
	
int i=0, a=1;
 int[] p={1,3,5,2,6};

	
	@BeforeClass
	public void lb(){
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
	   dr = new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		
		
	}
	
	@BeforeClass
	public void login(){
		
		dr.findElement(By.xpath("//form/input[1]")).sendKeys("standard_user");
		dr.findElement(By.xpath("//form/input[2]")).sendKeys("secret_sauce");
		dr.findElement(By.xpath("//form/input[3]")).click();
		
	}
	
	@BeforeMethod
	public void bm(){
		
	                  obj.add_product(p[i],dr,a);

	}
	
    @Test(invocationCount=3)
	public void verify(){
		
//		                 if((expitem.compareTo(actitem)==0) && (exp_price.compareTo(act_price)==0)){
//			          
//			             System.out.println("product is succesfully verified");
//		                 } else { System.out.println("fail"); }
    	SoftAssert sa=new SoftAssert();
    	sa.assertEquals(actitem, expitem);
    	sa.assertEquals(act_price, exp_price);
    	sa.assertAll();
	        }
	
    @AfterMethod
    public void am(){
    	if(i<4) {
			dr.findElement(By.xpath("//div[@class='cart_footer']/a[1]")).click();
			
			}
			else
					dr.findElement(By.xpath("//div[@class='cart_footer']/a[2]")).click();
	          		a++;
	          		i++;
    	
    	
    }
    
    
	@AfterClass
	public void add_info(){
		                      dr.findElement(By.xpath("//a[text()='CHECKOUT']")).click();  //checkout
		                      dr.findElement(By.xpath("//div[@class='checkout_info']/input[1]")).sendKeys("kishore");
		                      dr.findElement(By.xpath("//div[@class='checkout_info']/input[2]")).sendKeys("kumar");
		                      dr.findElement(By.xpath("//div[@class='checkout_info']/input[3]")).sendKeys("600096");
		                      dr.findElement(By.xpath("//input[@class='btn_primary cart_button']")).click();  //continue
		
	}
		
 
}
