package Testng2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class AssertTest {
	
	

	
	
	
  private SoftAssert sa;


//@Test
//  public void t1() {
////	  String er="iphone",ar="iphone11";
////	  SoftAssert sa=new SoftAssert();
////	  sa.assertEquals(er,ar);
////	  sa.assertAll();
//	 // SoftAssert sa=new SoftAssert();
//	  System.out.println("hello hardassert");
//	  Assert.assertTrue(false);
//	  System.out.println("hardassert executed");
//	  
//  }
//  
//  
//  
//  @Test
//  public void t2() {
//	  //String er="samsung",ar="samsung";
//	  SoftAssert sa=new SoftAssert();
//	  sa.assertTrue(true);
//	  System.out.println("hello softassert");
//	  sa.assertTrue(false);
//	  System.out.println("softassert executed");
//	  sa.assertAll();
//  }
//  
  
 @Test
 public void t3(){
	  System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
	  WebDriver dr = new ChromeDriver();
	  dr.get("http://demowebshop.tricentis.com");
	  String title="Demo WebfsfShop";
	  String t="Demo Web Shop";
	  String act_title=dr.getTitle();
	  sa = new SoftAssert();
	  sa.assertEquals(t,act_title);
	  sa.assertEquals(title,act_title);
	  System.out.println("title is equal or not");
	  sa.assertAll();
  
}
}
