package Testng2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class addproductsauce {

	 String expitem,exp_price,actitem, act_price;
	 
	public void add_product(int p,WebDriver dr,int a){
		
     	
		  expitem=dr.findElement(By.xpath("//div[@class='inventory_list']/div["+p+"]/div[2]/a/div")).getText();
		  exp_price=dr.findElement(By.xpath("//div[@class='inventory_list']/div["+p+"]/div[3]/div")).getText();
		     	 dr.findElement(By.xpath("//div[@class='inventory_list']/div["+p+"]/div[3]/button")).click(); //item 1(add to cart)
		     	 dr.findElement(By.xpath("//div[@class='shopping_cart_container']/a/span")).click(); // go to cart
	     actitem=dr.findElement(By.xpath("//div[@class='cart_list']/div["+a+"]/div[2]/a/div")).getText();  
	     act_price = dr.findElement(By.xpath("//div[@class='cart_list']/div["+a+"]/div[2]/div[2]/div")).getText();
			    
		}
}
