package Dataprovider;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Dataprovidtest extends excel{

	Dataprovider_login d;
	
	@BeforeMethod
	public void get_data(){
		get_test_data();
	}
	
	@Test(dataProvider="login")
	public void test(String eid,String pwd,String exp_eid){
		
	  d = new Dataprovider_login();
		String a_eid=d.login(eid,pwd);
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(a_eid, exp_eid);
		sa.assertAll();
	}
	
	@DataProvider(name="login")
	public String[][] prov_data(){
		get_test_data();
		return testdata;
	}
	
}
