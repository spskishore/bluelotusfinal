package Dataprovider;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Dataprovider_login {

	String act_res;
	public String login(String eid,String pwd){
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		
		dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]/a")).click();
		dr.findElement(By.xpath("//div[@class='form-fields']/form/div[2]/input")).sendKeys(eid); //uname
		dr.findElement(By.xpath("//div[@class='form-fields']/form/div[3]/input")).sendKeys(pwd); //pwd
		dr.findElement(By.xpath("//div[@class='form-fields']/form/div[5]/input")).click();
		act_res=dr.findElement(By.xpath("//div[@class='header-links']/ul/li[1]/a")).getText();
		return act_res;
	}
}
