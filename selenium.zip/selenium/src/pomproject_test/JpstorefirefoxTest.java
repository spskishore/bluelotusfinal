package pomproject_test;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pom_project.login_pom;
import pom_project.regi_pom;
import pom_project.utilities;
import pom_project.wait_type;

public class JpstorefirefoxTest {
  
	
WebDriver dr;
	
	login_pom l;
	regi_pom r;
	utilities u;
	wait_type w;
	
	String url="https://jpetstore.cfapps.io/login";
	
	@BeforeClass
	public void launch_chr()
	{
		dr=u.launch_browser("FIREFOX", url);
	}
	
	
	
  @Test
  public void f() {
	  w=new wait_type(dr);
	  u=new utilities(dr);
	  
//	  r=new regi_pom(dr);
//	  r.do_reg("kylie", "abc123456", "abc123456","kylie","jr","kylie@gmail.com","256637882","ded","newhd","deed","232","usa","English","DOGS");
	  
	  l=new login_pom(dr);
	  l.do_login("kriz", "abc123456");
	  
	  String act_msg=l.get_name();
	  Assert.assertTrue(act_msg.contains("Welcome kriz !"));
	  u.screensh();
  }
  
  @AfterClass
  public void ac() {
	  dr.close();
  }
}
