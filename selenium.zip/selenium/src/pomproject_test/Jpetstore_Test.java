package pomproject_test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pom_project.login_pom;
import pom_project.regi_pom;
import pom_project.utilities;
import pom_project.wait_type;

public class Jpetstore_Test {
	
WebDriver dr;
	
	login_pom l;
	regi_pom r;
	utilities u;
	wait_type w;
	
	String url="https://jpetstore.cfapps.io/login";
	
	@BeforeClass
	public void launch_chr()
	{
		dr=u.launch_browser("CHROME", url);
	}
	
	
	
  @Test
  public void test() {
	  w=new wait_type(dr);
	  u=new utilities(dr);
	  
//	  r=new regi_pom(dr);
//	  r.do_reg("kriz", "abc123456", "abc123456","kriz","jr","kiki@gmail.com","256637882","ded","newhd","deed","232","usa","English","DOGS");
	  
	  l=new login_pom(dr);
	  l.do_login("kriz", "abc123456");	  
	  String act_msg=l.get_name();

	  u.screensh();
	  Assert.assertTrue(act_msg.contains("Welcome kriz !"));
  }
  
//  @AfterTest
//  public void ac() {
//	  dr.close();
//  }
}
